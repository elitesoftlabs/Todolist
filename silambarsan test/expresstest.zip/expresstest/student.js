const express = require('express');
const app = express();


app.use(express.json());

app.post('/students', (req, res) => {
  const { name, age, course } = req.body;

  res.json({
    success: true,
    message: 'Student data received successfully!',
    data: { name, age, course }
  });
});

app.listen(4000, () => {
  console.log(`Server running on http://localhost:4000`);
});
