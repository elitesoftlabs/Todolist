const express = require('express');
const app = express();


app.get('/error', (req, res, next) => {
  next(new Error('Test error')); 
});


app.use((err, req, res, next) => {
  res.status(500).json({ error: 'Something went wrong!' });
});


app.listen(4000, () => {
  console.log(`Server running on http://localhost:4000`);
});
