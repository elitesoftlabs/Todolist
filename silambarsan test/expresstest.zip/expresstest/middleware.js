const express = require('express');
const app = express();
const PORT = 4000;

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next(); 
});

app.use(express.json());

app.get('/', (req, res) => {
  res.send('Welcome to ExpressJS Test!');
});

// GET route with route parameter
app.get('/user/:id', (req, res) => {
  const userId = req.params.id; 
  res.send(`You requested the user with ID: ${userId}`);
});

app.post('/students', (req, res) => {
  const { name, age, course } = req.body; 
  res.json({
    success: true,
    message: 'Student data received successfully!',
    data: { name, age, course }
  });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
