async function getPost() {
  try {
    const res = await fetch('https://jsonplaceholder.typicode.com/posts/1');
    const post = await res.json();
    console.log('Title:', post.title);
    console.log('Body:', post.body);
  } catch (err) {
    console.error('Error:', err);
  }
}

getPost();
