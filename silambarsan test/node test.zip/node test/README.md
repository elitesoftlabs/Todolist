# Uppercase File Converter

This simple Node.js script reads `input.txt`, converts its contents to uppercase, and writes the result to `output.txt`.

Usage:

1. Ensure you have Node.js installed.
2. From the project folder run:

   node ques1.js

3. Check `output.txt` for the uppercase content.
