const fs = require('fs');

fs.readFile('input.txt', 'utf8', (err, data) => {
  if (err) return console.error(err);
  fs.writeFile('output.txt', data.toUpperCase(), (err) => {
    if (err) return console.error(err);
    console.log('Done!');
  });
});
