const express = require('express');
const app = express();
app.use(express.json());

let students = ['Alice', 'Bob'];

app.get('/students', (req, res) => res.send(students));

app.post('/students', (req, res) => {
  if (!req.body.name) return res.status(400).send('Name required');
  students.push(req.body.name);
  res.send(students);
});

app.listen(3000, () => console.log('Server running on port 3000'));
