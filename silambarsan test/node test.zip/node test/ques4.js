const { EventEmitter } = require('events');

class MyEmitter extends EventEmitter {
  greet(msg) { this.emit('greet', msg); }
}

const emitter = new MyEmitter();
emitter.on('greet', console.log);
emitter.greet('Hello Students');