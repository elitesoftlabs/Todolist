import React from 'react';

const Child = ({ text }) => {
  return <h3>Received from Parent: {text}</h3>;
};

export default Child;
