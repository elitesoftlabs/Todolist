import  { useState } from 'react';

function Add() {
  const [count, setCount] = useState(0); 

  const Click = () => {setCount(count + 1);  };

  return (
    <div>
      <h2>NUMBER: {count}</h2>
      <button onClick={Click}>Increment</button>
    </div>
  );
}

export default Add;
