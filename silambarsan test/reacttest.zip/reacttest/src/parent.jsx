import React from 'react';
import Child from './Child';

const Parent = () => {
  const msg = "Hi! this is parent to child";

  return (
    <div>
      <h2>Parent</h2>
      <Child text={msg} />
    </div>
  );
};

export default Parent;
