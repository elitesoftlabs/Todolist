import React from 'react';

function Home() {
  return <h2>MERN full stack</h2>;
}

export default Home;
