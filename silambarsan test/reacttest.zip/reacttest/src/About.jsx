import React from 'react';

function About() {
  return <h2>This is MERN full stack course.</h2>;
}

export default About;
