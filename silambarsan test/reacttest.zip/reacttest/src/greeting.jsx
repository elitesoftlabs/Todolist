import React from 'react';

function Greeting() {
  return <h1>Hello, ReactJS!</h1>;
}

export default Greeting;
