import React from 'react';

function About() {
  return (
    <div style={{ padding: '10px' }}>
      <h1>About Page</h1>
      <p>This is the About Page of our React app.</p>
    </div>
  );
}

export default About;
