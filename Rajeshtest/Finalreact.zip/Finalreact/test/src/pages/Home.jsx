import React from 'react';

function Home() {
  return (
    <div style={{ padding: '10px' }}>
      <h1>Home Page</h1>
      <p>Welcome to the Home Page of the React.js!</p>
    </div>
  );
}

export default Home;
