import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import Greeting from "./components/Greeting";
import Counter from "./components/Counter";
import UserList from "./components/UserList";
import Parent from "./components/Parent";
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
