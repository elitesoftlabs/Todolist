import React from 'react';

function Child({ message }) {
  return (
    <div style={{ padding: '10px', border: '1px solid #ccc', marginTop: '10px' }}>
      <h4>Child Component</h4>
      <p>Message from Parent: {message}</p>
    </div>
  );
}

export default Child;
