import Child from './Child';

function Parent() {
  const parentMessage = "Hello I am from Parent Component!";
  
  return (
    <div style={{ padding: '10px', border: '1px solid #000', marginTop: '10px' }}>
      <h3>Parent Component</h3>
      <Child message={parentMessage} />
    </div>
  );
}

export default Parent;
