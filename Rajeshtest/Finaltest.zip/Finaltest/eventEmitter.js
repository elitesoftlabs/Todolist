const EventEmitter = require('events');
const myEmitter = new EventEmitter();

myEmitter.on('greet', (message) => {
  console.log(message);
});

myEmitter.emit('greet', 'Hello from EventEmitter!');