const express = require('express');
const app = express();
app.use(express.json());

let students = ['Arun Kumar', 'Rajesh',];

app.get('/students', (req, res) => {
  res.json(students);
});

app.post('/students', (req, res) => {
  const { name } = req.body;
  if (name) {
    students.push(name);
    res.json({ message: `Added successfully`, students });
  } else {
    res.status(400).json({ message: 'Name is required' });
  }
});

app.listen(3000, () => {
  console.log('Express server running on http://localhost:3000');
});
