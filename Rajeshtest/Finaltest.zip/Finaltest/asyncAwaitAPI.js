const fetch = require('node-fetch');

async function fetchposts() {
    try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts/1');
        const post = await response.json();
          console.log('Title:', post.title);
          console.log('Body:', post.body);
    }
    catch (error) {
        console.error('Error fetching posts:', error);
    }
}

fetchposts();